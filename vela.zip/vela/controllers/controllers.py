# -*- coding: utf-8 -*-
# from odoo import http


# class Vela(http.Controller):
#     @http.route('/vela/vela', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/vela/vela/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('vela.listing', {
#             'root': '/vela/vela',
#             'objects': http.request.env['vela.vela'].search([]),
#         })

#     @http.route('/vela/vela/objects/<model("vela.vela"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('vela.object', {
#             'object': obj
#         })

