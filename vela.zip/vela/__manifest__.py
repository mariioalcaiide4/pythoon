# -*- coding: utf-8 -*-
{
    'name': "Escuela de Vela",
    'summary': "Módulo de prueba",
    'description': "Long description of module's purpose",
    'author': "Mario Alcaide Pérez",
    'website': "https://www.yourcompany.com",
    'category': 'Uncategorized',
    'version': '3.7',
    'depends': ['base'],
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
    ],
    'demo': [
        'demo/demo.xml',
    ],
    'installable': True,   # Asegura que el módulo pueda instalarse
    'application': True    # Lo hace visible en el menú de aplicaciones
}
