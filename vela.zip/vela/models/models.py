# -*- coding: utf-8 -*-

from odoo import models, fields, api


class Escuela(models.Model):
     _name = 'escuela.vela'
     _description = 'Escuelas'

     denominacion = fields.Char(string="Denominación", required=True)
     logotipo = fields.Binary(string="Logotipo", required=True)
     telefono = fields.Integer(string="Teléfono", required=True)
     email = fields.Char(string="E-Mail", required=True)
     direccion = fields.Text(string="Dirección", required=True)

class Curso(models.Model):

     _name = 'escuela.curso'     
     _description = 'Cursos'

     titulo = fields.Char(string="Título")
     duracion = fields.Integer(string="Duración (en días)")
     horas = fields.Integer(string="Horas")
     precio = fields.Char(string="Precio (€)")
     escuela_id = fields.Many2one("escuela.vela", string="Escuela")

class Monitor(models.Model):

     _name = 'escuela.monitor'
     _description = 'Monitores'

     nombre = fields.Char(string= "Nombre completo", required=True)
     email = fields.Char(string= "E-Mail")
     telefono = fields.Integer(string= "Número de teléfono" )
     direccion = fields.Text(string= "Dirección")
     codigo_identificacion = fields.Char(string= "Código de Identificación", required=True, unique=True)
     escuelas = fields.Many2many("escuela.vela", string= "Escuelas")

class Alumno(models.Model):

     _name = 'escuela.alumno'
     _description = 'Alumnos'

     nombre = fields.Char(string = "Nombre completo", required=True)
     email = fields.Char(string = "E-Mail")
     telefono = fields.Integer(string = "Teléfono")
     direccion = fields.Text(string = "Dirección")
     matricula = fields.Char(string = "Mátricula", required=True, unique=True)
     escuela_id = fields.Many2one("escuela.vela", string="Escuela perteneciente")








#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100 

